package com.zerotools.crosshair;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    int shape = 0, color = Color.RED, size = 42;
    LinearLayout root;
    TextView status;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        root = new LinearLayout(this); root.setOrientation(1); root.setPadding(24,28,24,24); root.setBackgroundColor(Color.rgb(10,10,14));
        ScrollView scroll = new ScrollView(this); scroll.addView(root); setContentView(scroll);
        TextView title = new TextView(this); title.setText("CROSSHAIR HEADSHOT PRO"); title.setTextColor(Color.RED); title.setTextSize(25); title.setGravity(Gravity.CENTER); title.setPadding(0,12,0,8); root.addView(title);
        TextView sub = new TextView(this); sub.setText("FF Biasa • FF MAX  |  VISUAL AIM GUIDE"); sub.setTextColor(Color.WHITE); sub.setGravity(Gravity.CENTER); sub.setPadding(0,0,0,24); root.addView(sub);
        status = new TextView(this); status.setText("Status: belum aktif"); status.setTextColor(Color.LTGRAY); status.setPadding(0,12,0,12); root.addView(status);
        addButton("IZINKAN TAMPIL DI ATAS APLIKASI", v -> { if (!Settings.canDrawOverlays(this)) startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName()))); else status.setText("Izin overlay sudah aktif"); });
        TextView sh = label("Pilih bentuk crosshair"); root.addView(sh);
        String[] shapes = {"＋ Plus", "× X", "◎ Lingkaran", "✣ Tanda bidik", "• Titik"};
        Spinner sp = new Spinner(this); sp.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, shapes)); sp.setSelection(shape); sp.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){ public void onNothingSelected(android.widget.AdapterView<?> p){} public void onItemSelected(android.widget.AdapterView<?> p, View v,int pos,long id){shape=pos; update();}}); root.addView(sp);
        root.addView(label("Warna"));
        String[] colors={"Merah","Hijau","Biru","Putih","Kuning"}; int[] vals={Color.RED,Color.GREEN,Color.CYAN,Color.WHITE,Color.YELLOW};
        Spinner cs=new Spinner(this); cs.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,colors)); cs.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> p){} public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){color=vals[pos];update();}}); root.addView(cs);
        root.addView(label("Ukuran crosshair")); SeekBar sb=new SeekBar(this); sb.setMax(90); sb.setProgress(32); sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar s,int p,boolean u){size=18+p;update();} public void onStartTrackingTouch(SeekBar s){} public void onStopTrackingTouch(SeekBar s){}}); root.addView(sb);
        addButton("AKTIFKAN CROSSHAIR", v -> { if (!Settings.canDrawOverlays(this)) { startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName()))); Toast.makeText(this,"Izinkan tampil di atas aplikasi, lalu tekan aktifkan lagi",Toast.LENGTH_LONG).show(); return; } update(); startService(new Intent(this,CrosshairService.class)); status.setText("Status: crosshair aktif • geser untuk memindahkan"); });
        addButton("MATIKAN CROSSHAIR", v -> { stopService(new Intent(this,CrosshairService.class)); status.setText("Status: tidak aktif"); });
        TextView note=label("Catatan: aplikasi ini hanya menampilkan reticle visual. Tidak mengubah Free Fire, tidak mengunci target, dan tidak menjamin headshot. Overlay mungkin dibatasi oleh pengaturan/perlindungan game."); note.setTextSize(13); root.addView(note);
    }
    TextView label(String s){TextView t=new TextView(this);t.setText(s);t.setTextColor(Color.WHITE);t.setPadding(0,18,0,8);return t;}
    void addButton(String text, View.OnClickListener l){Button b=new Button(this);b.setText(text);b.setTextColor(Color.WHITE);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(170,0,0)));b.setOnClickListener(l);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,10,0,10);root.addView(b,p);}
    void update(){getSharedPreferences("cfg",0).edit().putInt("shape",shape).putInt("color",color).putInt("size",size).apply();}
}
