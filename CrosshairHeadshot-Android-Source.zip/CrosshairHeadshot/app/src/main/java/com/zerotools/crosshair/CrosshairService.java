package com.zerotools.crosshair;

import android.app.Service;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;

public class CrosshairService extends Service {
    WindowManager wm; AimView aim; WindowManager.LayoutParams lp;
    @Override public void onCreate(){super.onCreate(); wm=(WindowManager)getSystemService(WINDOW_SERVICE); aim=new AimView(); int type=android.os.Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE; lp=new WindowManager.LayoutParams(150,150,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT); lp.gravity=Gravity.TOP|Gravity.LEFT; lp.x= getResources().getDisplayMetrics().widthPixels/2-75; lp.y=getResources().getDisplayMetrics().heightPixels/2-75; wm.addView(aim,lp); }
    @Override public int onStartCommand(Intent i,int f,int id){if(aim!=null)aim.invalidate();return START_STICKY;}
    @Override public void onDestroy(){if(aim!=null){wm.removeView(aim);aim=null;}super.onDestroy();}
    @Override public IBinder onBind(Intent i){return null;}
    class AimView extends View {
        Paint p=new Paint(3); int shape,color,size; float downX,downY; int startX,startY;
        AimView(){super(CrosshairService.this);setLayerType(View.LAYER_TYPE_SOFTWARE,null);load();}
        void load(){android.content.SharedPreferences c=getSharedPreferences("cfg",0);shape=c.getInt("shape",0);color=c.getInt("color",Color.RED);size=c.getInt("size",42);}
        @Override protected void onDraw(Canvas c){super.onDraw(c);load();float x=getWidth()/2f,y=getHeight()/2f,r=size/2f;p.setColor(color);p.setStrokeWidth(4);p.setStyle(Paint.Style.STROKE);p.setShadowLayer(8,color,0,8);switch(shape){case 0:c.drawLine(x-r,y,x+r,y,p);c.drawLine(x,y-r,x,y+r,p);break;case 1:c.drawLine(x-r,y-r,x+r,y+r,p);c.drawLine(x-r,y+r,x+r,y-r,p);break;case 2:c.drawCircle(x,y,r,p);c.drawCircle(x,y,3,p);break;case 3:c.drawCircle(x,y,r*.65f,p);c.drawLine(x-r,y,x-r*.35f,y,p);c.drawLine(x+r*.35f,y,x+r,y,p);c.drawLine(x,y-r,x,y-r*.35f,p);c.drawLine(x,y+r*.35f,x,y+r,p);break;default:p.setStyle(Paint.Style.FILL);c.drawCircle(x,y,5,p);break;}p.clearShadowLayer();}
        @Override public boolean onTouchEvent(MotionEvent e){if(e.getAction()==MotionEvent.ACTION_DOWN){downX=e.getRawX();downY=e.getRawY();startX=lp.x;startY=lp.y;return true;}if(e.getAction()==MotionEvent.ACTION_MOVE){lp.x=startX+(int)(e.getRawX()-downX);lp.y=startY+(int)(e.getRawY()-downY);wm.updateViewLayout(this,lp);return true;}return true;}
    }
}
