CROSSHAIR HEADSHOT PRO - ANDROID PROJECT
Target: Android 6.0+ (API 23+), FF Biasa / FF MAX as a visual overlay utility.

IMPORTANT
- This project is source code, not a compiled APK.
- It displays a movable visual crosshair only. It does not provide auto-aim, target locking, recoil control, or guaranteed headshots.
- Android requires the user to grant "Display over other apps" permission.
- Some games/device security settings may block overlays.

BUILD
1. Open this folder in Android Studio.
2. Allow Gradle sync (Android Gradle Plugin 8.7.3; compile SDK 35).
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Install the generated APK and grant overlay permission.
